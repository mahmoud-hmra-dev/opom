All database DDLs, DMLs and migrations relates to the application should be stored here as well.
