Validators are expressjs middlewares that validate the request body.
