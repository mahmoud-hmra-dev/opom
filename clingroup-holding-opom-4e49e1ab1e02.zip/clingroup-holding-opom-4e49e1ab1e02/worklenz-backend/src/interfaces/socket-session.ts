export interface ISocketSession {
  session?: {
    passport?: { user?: string; }
  }
}
