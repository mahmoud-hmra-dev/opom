export interface ISerializeCallback {
  (error: string | null, id: string | null): void;
}
