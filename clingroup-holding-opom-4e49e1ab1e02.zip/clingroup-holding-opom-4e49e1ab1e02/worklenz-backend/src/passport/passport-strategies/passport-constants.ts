export const SUCCESS_KEY = "success";
export const ERROR_KEY = "error";
